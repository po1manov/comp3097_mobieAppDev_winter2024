//
//  labTest1Tests.swift
//  labTest1Tests
//
//  Created by Egor Poimanov ID:101249541 on 2024-02-06.
//
import XCTest
@testable import labTest1

class labTest1Tests: XCTestCase {

    func testDrawNumbers() {
        var generatedNumbers = Set<Int>()
        
        while generatedNumbers.count < 6 {
            generatedNumbers.insert(Int.random(in: 1...65))
        }
        let numbers = generatedNumbers.sorted()

        XCTAssertEqual(numbers.count, 6, "drawNumbers should generate exactly 6 numbers.")
        for number in numbers {
            XCTAssertTrue(number >= 1 && number <= 65, "Number \(number) is out of the lottery range.")
        }
        XCTAssertEqual(Set(numbers).count, 6, "All numbers should be unique.")
    }
    
}




//import XCTest
//
//final class labTest1Tests: XCTestCase {
//
//    override func setUpWithError() throws {
//        // Put setup code here. This method is called before the invocation of each test method in the class.
//    }
//
//    override func tearDownWithError() throws {
//        // Put teardown code here. This method is called after the invocation of each test method in the class.
//    }
//
//    func testExample() throws {
//        // This is an example of a functional test case.
//        // Use XCTAssert and related functions to verify your tests produce the correct results.
//        // Any test you write for XCTest can be annotated as throws and async.
//        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
//        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
//    }
//
//    func testPerformanceExample() throws {
//        // This is an example of a performance test case.
//        measure {
//            // Put the code you want to measure the time of here.
//        }
//    }
//}

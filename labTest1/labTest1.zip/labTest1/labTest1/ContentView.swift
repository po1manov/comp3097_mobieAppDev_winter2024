//
//  ContentView.swift
//  labTest1
//
//  Created by Egor Poimanov ID:101249541 on 2024-02-06.
//
import SwiftUI

struct ContentView: View {
    @State private var numbers = Array(repeating: "--", count: 6)

    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    ForEach(0..<6) { index in
                        Text(numbers[index])
                            .frame(width: 44, height: 44)
                            .border(Color.gray)
                            .padding(4)
                    }
                }
                .font(.title)

                Button("Draw") {
                    drawNumbers()
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(8)

                Button("Reset") {
                    resetNumbers()
                }
                .padding()
                .background(Color.red)
                .foregroundColor(.white)
                .cornerRadius(8)

                NavigationLink(destination: AuthorInfoView()) {
                    Text("Info")
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
            }
            .navigationTitle("LabTest1 - Lottery Draw")
        }
    }

    func drawNumbers() {
        var generatedNumbers = Set<Int>()
        while generatedNumbers.count < 6 {
            generatedNumbers.insert(Int.random(in: 1...65))
        }
        numbers = generatedNumbers.sorted().map { String($0) }
    }

    func resetNumbers() {
        numbers = Array(repeating: "--", count: 6)
    }
}

struct AuthorInfoView: View {
    var body: some View {
        VStack(spacing: 10) {
            Group {
                Text("Author:")
                    .font(.headline)
                Text("Egor Poimanov")
                    .font(.title)
            }
            Group {
                Text("Student ID:")
                    .font(.headline)
                Text("101249541")
                    .font(.title)
            }
        }
        .navigationTitle("About Author")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

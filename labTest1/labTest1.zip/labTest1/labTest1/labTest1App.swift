//
//  labTest1App.swift
//  labTest1
//
//  Created by Egor Poimanov ID:101249541 on 2024-02-06.
//

import SwiftUI

@main
struct labTest1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
